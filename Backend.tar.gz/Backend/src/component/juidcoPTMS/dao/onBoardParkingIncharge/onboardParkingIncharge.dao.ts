import { Request } from "express";
import pool from "../../../../lib/database/db";
import { ParkingInchargeType } from "../../../../util/types/index";
import { generateRes } from "../../../../util/generateRes";

class ParkingInchargeDao {
  async create(req: Request) {
    try {
      const {
        first_name,
        middle_name,
        last_name,
        age,
        blood_grp,
        mobile_no,
        address,
        email_id,
        emergency_mob_no,
        kyc_doc,
        fitness_doc,
        cunique_id,
      }: ParkingInchargeType = req.body;

      const date = new Date();

      const query = `
        INSERT INTO parking_incharge (
          first_name,
          middle_name,
          last_name,
          age,
          blood_grp,
          mobile_no,
          address,
          email_id,
          emergency_mob_no,
          cunique_id,
          kyc_doc,
          fitness_doc,
          updated_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13) RETURNING *;
        `;

      const values = [
        first_name,
        middle_name,
        last_name,
        age,
        blood_grp,
        mobile_no,
        address,
        email_id,
        emergency_mob_no,
        cunique_id,
        kyc_doc,
        fitness_doc,
        date,
      ];

      const { rows } = await pool.query(query, values);

      return generateRes(rows[0]);
    } catch (error: any) {
      console.error("Error creating parking incharge:", error);
      return { ...error, status: "ERROR" };
    }
  }

  async get(req: Request) {
    const { cunique_id, name, search } = req.query;

    const qr_func = (extend?: string) => {
      return `
        SELECT * FROM parking_incharge ${extend}
      `;
    };
    let qr = qr_func();

    // ------------------  FILTER ------------------//
    if (search !== "" && search !== undefined) {
      qr = qr_func(`
        WHERE 
        first_name ILIKE $1 
        OR last_name ILIKE $1 
        OR CAST(cunique_id AS TEXT) ILIKE $1;
      `);
    }

    if (cunique_id !== "" && cunique_id !== undefined) {
      qr = qr_func(`
        WHERE cunique_id ILIKE '${cunique_id}'
      `);
    }

    if (name !== "" && name !== undefined) {
      qr = qr_func(`
        WHERE first_name ILIKE '${name}'
      `);
    }
    // -------------------  FILTER -------------------//

    const values = [`%${search}%`];
    const { rows } = await pool.query(qr, search ? values : []);
    return generateRes(rows);
  }
}

export default ParkingInchargeDao;
