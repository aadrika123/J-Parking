import { Request } from "express";
import pool from "../../../../lib/database/db";
import { ParkingAreaType } from "../../../../util/types/index";
import { generateRes } from "../../../../util/generateRes";

class ParkingAreaDao {
  async create(req: Request) {
    try {
      const {
        address,
        zip_code,
        station,
        landmark,
        two_wheeler_capacity,
        four_wheeler_capacity,
        total_parking_area,
        type_parking_space,
        agreement_doc
      }: ParkingAreaType = req.body;

      const date = new Date();

      const query = `
        INSERT INTO parking_area (
          address,
          zip_code,
          station,
          landmark,
          two_wheeler_capacity,
          four_wheeler_capacity,
          total_parking_area,
          type_parking_space,
          agreement_doc,
          updated_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *;
        `;

      const values = [
        address,
        zip_code,
        station,
        landmark,
        two_wheeler_capacity,
        four_wheeler_capacity,
        total_parking_area,
        type_parking_space,
        agreement_doc,
        date,
      ];

      const { rows } = await pool.query(query, values);
      console.log(rows);
      return generateRes(rows[0]);
    } catch (error: any) {
      console.error("Error creating parking area:", error);
      return { ...error, status: "ERROR" };
    }
  }
}

export default ParkingAreaDao;
