import { Request, Response } from "express";
import CommonRes from "../../../../util/helper/commonResponse";
// import { parkingInchargeValidationSchema } from "../../validators/onBoardParkingIncharge/onboardParkingIncharge.validate";
import { resObj } from "../../../../util/types";
import ParkingAreaDao from "../../dao/onBoardParkingArea/onboardParkingArea";

class ParkingAreaController {
  private parkingAreaDao: ParkingAreaDao;

  constructor() {
    this.parkingAreaDao = new ParkingAreaDao();
  }
  async create(req: Request, res: Response, apiId: string) {
    const resObj: resObj = {
      apiId,
      action: "POST",
      version: "1.0",
    };

    try {
      const data = await this.parkingAreaDao.create(req);

      if (data.status === "ERROR") {
        return res.json({
          error: data.detail,
        });
      }

      return CommonRes.SUCCESS(
        "Area Added Successfully",
        data,
        resObj,
        res
      );
    } catch (error) {
      return CommonRes.SERVER_ERROR(error, resObj, res);
    }
  }
}
export default ParkingAreaController;
