import { Request, Response } from "express";
import CommonRes from "../../../../util/helper/commonResponse";
// import { parkingInchargeValidationSchema } from "../../validators/onBoardParkingIncharge/onboardParkingIncharge.validate";
import { resObj } from "../../../../util/types";
import ParkingInchargeDao from "../../dao/onBoardParkingIncharge/onboardParkingIncharge.dao";

class ParkingInchargeController {
  private parkingInchargeDao: ParkingInchargeDao;

  constructor() {
    this.parkingInchargeDao = new ParkingInchargeDao();
  }
  async create(req: Request, res: Response, apiId: string) {
    const resObj: resObj = {
      apiId,
      action: "POST",
      version: "1.0",
    };

    try {
      const data = await this.parkingInchargeDao.create(req);

      if (data.status === "ERROR") {
        return res.json({
          error: data.detail,
        });
      }

      return CommonRes.SUCCESS(
        "Incharge Added Successfully",
        data,
        resObj,
        res
      );
    } catch (error) {
      return CommonRes.SERVER_ERROR(error, resObj, res);
    }
  }

  async get(req: Request, res: Response, apiId: string) {
    const resObj: resObj = {
      apiId,
      action: "GET",
      version: "1.0",
    };

    try {
      const data = await this.parkingInchargeDao.get(req);
      console.log(data, "d");

      if (data?.status === "ERROR") {
        return res.json({
          error: data.detail,
        });
      }

      if (!data) {
        return res.json({
          message: "NO DATA FOUND",
        });
      }

      return CommonRes.SUCCESS(
        "Incharge Added Successfully",
        data,
        resObj,
        res
      );
    } catch (error) {
      return CommonRes.SERVER_ERROR(error, resObj, res);
    }
  }
}
export default ParkingInchargeController;
