import Joi from "joi";

export const parkingInchargeValidationSchema = Joi.object({
  first_name: Joi.string().required(),
  middle_name: Joi.string(),
  email_id: Joi.string(),
  last_name: Joi.string().required(),
  age: Joi.string().required(),
  blood_grp: Joi.string().required(),
  mobile_no: Joi.string().required(),
  emergency_mob_no: Joi.string(),
});
