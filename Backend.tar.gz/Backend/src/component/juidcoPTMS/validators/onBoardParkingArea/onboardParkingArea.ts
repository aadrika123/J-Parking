import Joi from "joi";

export const parkingAreaValidationSchema = Joi.object({
  address: Joi.string().required(),
  zip_code: Joi.string().required(),
  station: Joi.string().required(),
  landmark: Joi.string().required(),
  two_wheeler_capacity: Joi.string().required(),
  four_wheeler_capacity: Joi.string().required(),
  agreement_doc: Joi.string().required(),
});
