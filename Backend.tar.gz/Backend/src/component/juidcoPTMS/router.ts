import express from "express";
import OnBoardingInchargeRoute from "./route/onBoardingParkingIncharge/onBoardingParkingIncharge.route";
import OnBoardingAreaRoute from "./route/onBoardingParkingArea/onBoardingParkingArea.route";
import FileUploadRoute from "./route/fileUpload.route";

/*
|--------------------------------------------------------------------------
| API Routes
| Author- Krish
| Created On- 06-06-2024 
| Created for- juidco_parking
| Module status- Open
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application.
|
*/
/**
 * | Comman Route for ptms
 */

export default class PtmsRoute {
  constructor(app: express.Application) {
    new FileUploadRoute(app);
    new OnBoardingInchargeRoute(app);
    new OnBoardingAreaRoute(app);
  }
}
