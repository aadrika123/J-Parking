import express, { Request, Response } from "express";
import { baseUrl } from "../../../../util/common";
import ParkingInchargeController from "../../controller/onBoardingParkingIncharge/onBoardingParkingIncharge.controller";
import { upload } from "../../../../middleware/fileUpload.middleware";
export default class OnBoardingInchargeRoute {
  constructor(app: express.Application) {
    const parkingInchargeController = new ParkingInchargeController();
    this.init(app, parkingInchargeController);
  }

  init(
    app: express.Application,
    parkingInchargeController: ParkingInchargeController
  ): void {
    app.route(`${baseUrl}/onboard-parking-incharge`).post(
      upload.fields([
        {
          name: "kyc_doc",
        },
        {
          name: "fitness_doc",
        },
      ]),
      (req: Request, res: Response) =>
        parkingInchargeController.create(req, res, "0101")
    );

    app
      .route(`${baseUrl}/get-parking-incharge`)
      .get((req: Request, res: Response) =>
        parkingInchargeController.get(req, res, "0102")
      );
  }
}
